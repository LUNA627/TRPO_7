﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace prack6_TRPO
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
